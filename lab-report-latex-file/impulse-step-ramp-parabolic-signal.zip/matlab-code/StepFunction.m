function out=StepFunction(n)
if n>=0
    out=1;
else
    out=0;
end
end