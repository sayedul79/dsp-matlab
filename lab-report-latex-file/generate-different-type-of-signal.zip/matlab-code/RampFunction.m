function out=RampFunction(n)
out=n*StepFunction(n);
end
