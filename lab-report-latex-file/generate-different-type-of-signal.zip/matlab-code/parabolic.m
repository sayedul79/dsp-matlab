function out=parabolic(n)
out=n^2*StepFunction(n);
end